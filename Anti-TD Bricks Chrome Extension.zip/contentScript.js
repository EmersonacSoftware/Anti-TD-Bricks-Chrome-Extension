const replaceText = (node) => {
   const text = node.textContent;
   const replacedText = text.replace(/TD Bricks|TDBRICKS/gi, 'TD Cringe');
   if (replacedText !== text) {
      node.textContent = replacedText;
   }
};

const observer = new MutationObserver((mutations) => {
   mutations.forEach((mutation) => {
      mutation.addedNodes.forEach((node) => {
         if (node.nodeType === Node.TEXT_NODE) {
            replaceText(node);
         }
      });
   });
});

observer.observe(document.body, {
   childList: true,
   subtree: true
});
